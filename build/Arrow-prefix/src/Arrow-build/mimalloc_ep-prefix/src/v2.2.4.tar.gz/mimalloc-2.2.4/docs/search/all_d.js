var searchData=
[
  ['the_20library_0',['Using the library',['../using.html',1,'']]],
  ['typed_20macros_1',['Typed Macros',['../group__typed.html',1,'']]]
];
