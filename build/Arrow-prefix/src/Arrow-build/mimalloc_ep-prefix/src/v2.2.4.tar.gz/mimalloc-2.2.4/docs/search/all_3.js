var searchData=
[
  ['c_20wrappers_0',['C++ wrappers',['../group__cpp.html',1,'']]],
  ['committed_1',['committed',['../group__analysis.html#ab47526df656d8837ec3e97f11b83f835',1,'mi_heap_area_t']]]
];
