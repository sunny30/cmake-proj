var group__aligned =
[
    [ "mi_calloc_aligned", "group__aligned.html#ga424ef386fb1f9f8e0a86ab53f16eaaf1", null ],
    [ "mi_calloc_aligned_at", "group__aligned.html#ga977f96bd2c5c141bcd70e6685c90d6c3", null ],
    [ "mi_malloc_aligned", "group__aligned.html#ga69578ff1a98ca16e1dcd02c0995cd65c", null ],
    [ "mi_malloc_aligned_at", "group__aligned.html#ga2022f71b95a7cd6cce1b6e07752ae8ca", null ],
    [ "mi_realloc_aligned", "group__aligned.html#ga5d7a46d054b4d7abe9d8d2474add2edf", null ],
    [ "mi_realloc_aligned_at", "group__aligned.html#gad06dcf2bb8faadb2c8ea61ee5d24bbf6", null ],
    [ "mi_zalloc_aligned", "group__aligned.html#gaac7d0beb782f9b9ac31f47492b130f82", null ],
    [ "mi_zalloc_aligned_at", "group__aligned.html#ga7c1778805ce50ebbf02ccbd5e39d5dba", null ]
];