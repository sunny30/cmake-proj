var searchData=
[
  ['aligned_20allocation_0',['Aligned Allocation',['../group__aligned.html',1,'']]],
  ['allocation_1',['Allocation',['../group__aligned.html',1,'Aligned Allocation'],['../group__malloc.html',1,'Basic Allocation'],['../group__heap.html',1,'Heap Allocation']]],
  ['allocation_2',['Zero initialized re-allocation',['../group__zeroinit.html',1,'']]]
];
