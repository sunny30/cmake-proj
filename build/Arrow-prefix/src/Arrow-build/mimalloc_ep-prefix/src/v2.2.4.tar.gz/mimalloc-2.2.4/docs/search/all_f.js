var searchData=
[
  ['wrappers_0',['C++ wrappers',['../group__cpp.html',1,'']]]
];
