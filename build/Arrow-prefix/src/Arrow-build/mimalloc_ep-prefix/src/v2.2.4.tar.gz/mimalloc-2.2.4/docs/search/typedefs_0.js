var searchData=
[
  ['mi_5farena_5fid_5ft_0',['mi_arena_id_t',['../group__extended.html#ga99fe38650d0b02e0e0f89ee024db91d3',1,'mimalloc-doc.h']]],
  ['mi_5fblock_5fvisit_5ffun_1',['mi_block_visit_fun',['../group__analysis.html#ga8255dc9371e6b299d9802a610c4e34ec',1,'mimalloc-doc.h']]],
  ['mi_5fdeferred_5ffree_5ffun_2',['mi_deferred_free_fun',['../group__extended.html#ga292a45f7dbc7cd23c5352ce1f0002816',1,'mimalloc-doc.h']]],
  ['mi_5ferror_5ffun_3',['mi_error_fun',['../group__extended.html#ga83fc6a688b322261e1c2deab000b0591',1,'mimalloc-doc.h']]],
  ['mi_5fheap_5ft_4',['mi_heap_t',['../group__heap.html#ga34a47cde5a5b38c29f1aa3c5e76943c2',1,'mimalloc-doc.h']]],
  ['mi_5foutput_5ffun_5',['mi_output_fun',['../group__extended.html#gadf31cea7d0332a81c8b882cbbdbadb8d',1,'mimalloc-doc.h']]],
  ['mi_5fsubproc_5fid_5ft_6',['mi_subproc_id_t',['../group__extended.html#ga8c0bcd1fee27c7641e9c3c0d991b3b7d',1,'mimalloc-doc.h']]]
];
