var searchData=
[
  ['re_20allocation_0',['Zero initialized re-allocation',['../group__zeroinit.html',1,'']]],
  ['runtime_20options_1',['Runtime Options',['../group__options.html',1,'']]]
];
