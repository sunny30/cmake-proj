var group__malloc =
[
    [ "mi_calloc", "group__malloc.html#ga6686568014b54d1e6c7ac64a076e4f56", null ],
    [ "mi_expand", "group__malloc.html#ga19299856216cfbb08e2628593654dfb0", null ],
    [ "mi_free", "group__malloc.html#gaf2c7b89c327d1f60f59e68b9ea644d95", null ],
    [ "mi_malloc", "group__malloc.html#gae1dd97b542420c87ae085e822b1229e8", null ],
    [ "mi_mallocn", "group__malloc.html#ga61f46bade3db76ca24aaafedc40de7b6", null ],
    [ "mi_realloc", "group__malloc.html#ga0621af6a5e3aa384e6a1b548958bf583", null ],
    [ "mi_reallocf", "group__malloc.html#ga4dc3a4067037b151a64629fe8a332641", null ],
    [ "mi_reallocn", "group__malloc.html#ga8bddfb4a1270a0854bbcf44cb3980467", null ],
    [ "mi_realpath", "group__malloc.html#ga94c3afcc086e85d75a57e9f76b9b71dd", null ],
    [ "mi_recalloc", "group__malloc.html#ga23a0fbb452b5dce8e31fab1a1958cacc", null ],
    [ "mi_strdup", "group__malloc.html#ga245ac90ebc2cfdd17de599e5fea59889", null ],
    [ "mi_strndup", "group__malloc.html#ga486d0d26b3b3794f6d1cdb41a9aed92d", null ],
    [ "mi_zalloc", "group__malloc.html#gae6e38c4403247a7b40d80419e093bfb8", null ]
];