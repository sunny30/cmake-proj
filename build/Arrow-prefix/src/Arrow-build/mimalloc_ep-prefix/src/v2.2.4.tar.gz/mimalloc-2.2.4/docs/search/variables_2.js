var searchData=
[
  ['full_5fblock_5fsize_0',['full_block_size',['../group__analysis.html#ab53664e31d7fe2564f8d42041ef75cb3',1,'mi_heap_area_t']]]
];
