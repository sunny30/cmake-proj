var searchData=
[
  ['heap_20allocation_0',['Heap Allocation',['../group__heap.html',1,'']]],
  ['heap_20introspection_1',['Heap Introspection',['../group__analysis.html',1,'']]]
];
