var searchData=
[
  ['initialized_20re_20allocation_0',['Zero initialized re-allocation',['../group__zeroinit.html',1,'']]],
  ['introspection_1',['Heap Introspection',['../group__analysis.html',1,'']]]
];
