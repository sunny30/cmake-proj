var searchData=
[
  ['basic_20allocation_0',['Basic Allocation',['../group__malloc.html',1,'']]]
];
