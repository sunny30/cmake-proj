var searchData=
[
  ['heap_20allocation_0',['Heap Allocation',['../group__heap.html',1,'']]],
  ['heap_20introspection_1',['Heap Introspection',['../group__analysis.html',1,'']]],
  ['heap_5ftag_2',['heap_tag',['../group__analysis.html#a2b7a0c92ece8daf46b558efc990ebdc1',1,'mi_heap_area_t']]]
];
