var searchData=
[
  ['macros_0',['Typed Macros',['../group__typed.html',1,'']]]
];
