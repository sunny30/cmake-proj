var group__cpp =
[
    [ "mi_stl_allocator< T >", "group__cpp.html#structmi__stl__allocator", null ],
    [ "mi_new", "group__cpp.html#ga633d96e3bc7011f960df9f3b2731fc6a", null ],
    [ "mi_new_aligned", "group__cpp.html#ga79c54da0b4b4ce9fcc11d2f6ef6675f8", null ],
    [ "mi_new_aligned_nothrow", "group__cpp.html#ga92ae00b6dd64406c7e64557711ec04b7", null ],
    [ "mi_new_n", "group__cpp.html#gadd11b85c15d21d308386844b5233856c", null ],
    [ "mi_new_nothrow", "group__cpp.html#ga5cb4f120d1f7296074256215aa9a9e54", null ],
    [ "mi_new_realloc", "group__cpp.html#ga6867d89baf992728e0cc20a1f47db4d0", null ],
    [ "mi_new_reallocn", "group__cpp.html#gaace912ce086682d56f3ce9f7638d9d67", null ]
];