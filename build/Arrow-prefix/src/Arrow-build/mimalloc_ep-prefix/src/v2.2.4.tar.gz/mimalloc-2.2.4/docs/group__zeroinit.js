var group__zeroinit =
[
    [ "mi_heap_recalloc", "group__zeroinit.html#gad1a0d325d930eeb80f25e3fea37aacde", null ],
    [ "mi_heap_recalloc_aligned", "group__zeroinit.html#ga87ddd674bf1c67237d780d0b9e0f0f32", null ],
    [ "mi_heap_recalloc_aligned_at", "group__zeroinit.html#ga07b5bcbaf00d0d2e598c232982588496", null ],
    [ "mi_heap_rezalloc", "group__zeroinit.html#ga8d8b7ebb24b513cd84d1a696048da60d", null ],
    [ "mi_heap_rezalloc_aligned", "group__zeroinit.html#ga5129f6dc46ee1613d918820a8a0533a7", null ],
    [ "mi_heap_rezalloc_aligned_at", "group__zeroinit.html#ga2bafa79c3f98ea74882349d44cffa5d9", null ],
    [ "mi_recalloc_aligned", "group__zeroinit.html#ga3e2169b48683aa0ab64f813fd68d839e", null ],
    [ "mi_recalloc_aligned_at", "group__zeroinit.html#gaae25e4ddedd4e0fb61b1a8bd5d452750", null ],
    [ "mi_rezalloc", "group__zeroinit.html#gadfd34cd7b4f2bbda7ae06367a6360756", null ],
    [ "mi_rezalloc_aligned", "group__zeroinit.html#ga4d02404fe1e7db00beb65f185e012caa", null ],
    [ "mi_rezalloc_aligned_at", "group__zeroinit.html#ga6843a88285bbfcc3bdfccc60aafd1270", null ]
];