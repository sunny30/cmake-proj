var searchData=
[
  ['extended_20functions_0',['Extended Functions',['../group__extended.html',1,'']]]
];
