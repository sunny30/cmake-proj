.. Copyright (c) 2016, Johan Mabille, Sylvain Corlay

   Distributed under the terms of the BSD 3-Clause License.

   The full license is in the file LICENSE, distributed with this software.

Batch of constants
==================

.. _xsimd-batch-constant-ref:

.. doxygenstruct:: xsimd::batch_constant
   :project: xsimd
   :members:


.. doxygenfunction:: xsimd::make_batch_constant
   :project: xsimd
